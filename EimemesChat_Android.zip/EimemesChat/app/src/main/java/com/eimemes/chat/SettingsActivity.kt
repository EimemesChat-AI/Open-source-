package com.eimemes.chat

import android.graphics.LinearGradient
import android.graphics.Shader
import android.os.Bundle
import android.view.WindowManager
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.switchmaterial.SwitchMaterial

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.setFlags(
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        )

        setContentView(R.layout.activity_settings)

        val btnBack = findViewById<ImageButton>(R.id.btnBack)
        val switchNotifications = findViewById<SwitchMaterial>(R.id.switchNotifications)
        val switchChatHistory = findViewById<SwitchMaterial>(R.id.switchChatHistory)
        val rowAppearance = findViewById<LinearLayout>(R.id.rowAppearance)
        val rowLanguage = findViewById<LinearLayout>(R.id.rowLanguage)
        val rowClearChats = findViewById<LinearLayout>(R.id.rowClearChats)
        val rowPrivacy = findViewById<LinearLayout>(R.id.rowPrivacy)
        val rowHelp = findViewById<LinearLayout>(R.id.rowHelp)
        val rowAbout = findViewById<LinearLayout>(R.id.rowAbout)

        btnBack.setOnClickListener {
            onBackPressed()
        }

        setupToggleSwitch(switchNotifications, true)
        setupToggleSwitch(switchChatHistory, true)

        rowAppearance.setOnClickListener {
            showToast("Appearance settings coming soon")
        }
        rowLanguage.setOnClickListener {
            showToast("Language settings coming soon")
        }
        rowClearChats.setOnClickListener {
            showToast("All chats cleared")
        }
        rowPrivacy.setOnClickListener {
            showToast("Privacy settings")
        }
        rowHelp.setOnClickListener {
            showToast("Help & Support")
        }
        rowAbout.setOnClickListener {
            showToast("EimemesChat AI v1.0.1")
        }
    }

    private fun setupToggleSwitch(switch: SwitchMaterial, defaultOn: Boolean) {
        // Style the switch manually to match iOS-style toggle
        switch.isChecked = defaultOn
        switch.trackTintList = null
        switch.thumbTintList = null
        switch.setBackgroundResource(R.drawable.selector_toggle_track)
    }

    private fun showToast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    override fun onBackPressed() {
        super.onBackPressed()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }
}
