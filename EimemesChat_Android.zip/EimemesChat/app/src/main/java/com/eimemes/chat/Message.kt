package com.eimemes.chat

data class Message(
    val id: Int,
    val type: MessageType,
    val text: String = "",
    val time: String = ""
)

enum class MessageType {
    WELCOME,
    AI,
    USER,
    TYPING
}
