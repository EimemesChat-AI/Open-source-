package com.eimemes.chat

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var drawerLayout: DrawerLayout
    private lateinit var recyclerView: RecyclerView
    private lateinit var etMessage: EditText
    private lateinit var btnMenu: ImageButton
    private lateinit var btnNewChat: ImageButton
    private lateinit var btnSend: ImageButton
    private lateinit var btnCloseSidebar: ImageButton
    private lateinit var btnSidebarSettings: LinearLayout
    private lateinit var recentChatsRecycler: RecyclerView

    private lateinit var messageAdapter: MessageAdapter
    private val messages = mutableListOf<Message>()
    private var messageIdCounter = 0

    private val recentChats = listOf(
        "iOS design tips",
        "Quantum computing explained",
        "Poem about stars",
        "Trip planner Paris",
        "Workout routine"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Edge-to-edge
        window.setFlags(
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        )

        setContentView(R.layout.activity_main)

        drawerLayout = findViewById(R.id.drawerLayout)
        recyclerView = findViewById(R.id.recyclerView)
        etMessage = findViewById(R.id.etMessage)
        btnMenu = findViewById(R.id.btnMenu)
        btnNewChat = findViewById(R.id.btnNewChat)
        btnSend = findViewById(R.id.btnSend)
        btnCloseSidebar = findViewById(R.id.btnCloseSidebar)
        btnSidebarSettings = findViewById(R.id.btnSidebarSettings)
        recentChatsRecycler = findViewById(R.id.recentChatsList)

        setupRecyclerView()
        setupSidebarRecentChats()
        setupListeners()
        populateInitialMessages()
        handleWideLayout()
    }

    private fun setupRecyclerView() {
        val layoutManager = LinearLayoutManager(this).apply {
            stackFromEnd = false
        }
        recyclerView.layoutManager = layoutManager
        messageAdapter = MessageAdapter(messages)
        recyclerView.adapter = messageAdapter
    }

    private fun setupSidebarRecentChats() {
        recentChatsRecycler.layoutManager = LinearLayoutManager(this)
        recentChatsRecycler.adapter = RecentChatAdapter(recentChats)
        recentChatsRecycler.isNestedScrollingEnabled = false
    }

    private fun populateInitialMessages() {
        addWelcome()
        addAiMessage("Hello! I'm Eimemes AI. How can I assist you today?", "10:41")
        addUserMessage("Can you help me design an iOS-style interface?", "10:42")
        addAiMessage("Of course! Use SF Pro, subtle blurs, and frosted glass.", "10:42")
        addTypingIndicator()
        scrollToBottom()
    }

    private fun setupListeners() {
        // Hamburger - open drawer
        btnMenu.setOnClickListener {
            if (!drawerLayout.isDrawerOpen(GravityCompat.START)) {
                drawerLayout.openDrawer(GravityCompat.START)
            }
        }

        // Close sidebar
        btnCloseSidebar.setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.START)
        }

        // New Chat
        btnNewChat.setOnClickListener {
            val time = currentTime()
            if (messageAdapter.hasTypingIndicator()) {
                messageAdapter.removeTypingIndicator()
            }
            addUserMessage(getString(R.string.new_chat_started), time)
            scrollToBottom()
        }

        // Send button
        btnSend.setOnClickListener {
            sendMessage()
        }

        // Send on keyboard action
        etMessage.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) {
                sendMessage()
                true
            } else false
        }

        // Settings from sidebar
        btnSidebarSettings.setOnClickListener {
            drawerLayout.closeDrawer(GravityCompat.START)
            startActivity(Intent(this, SettingsActivity::class.java))
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }

        // Drawer listener - hide hamburger when drawer opens in wide mode
        drawerLayout.addDrawerListener(object : DrawerLayout.DrawerListener {
            override fun onDrawerSlide(drawerView: View, slideOffset: Float) {}
            override fun onDrawerOpened(drawerView: View) {}
            override fun onDrawerClosed(drawerView: View) {}
            override fun onDrawerStateChanged(newState: Int) {}
        })
    }

    private fun sendMessage() {
        val text = etMessage.text.toString().trim()
        if (text.isEmpty()) return
        etMessage.setText("")
        val time = currentTime()

        // Remove typing indicator if present
        if (messageAdapter.hasTypingIndicator()) {
            messageAdapter.removeTypingIndicator()
        }

        addUserMessage(text, time)
        scrollToBottom()

        // Simulate AI typing response after 800ms
        recyclerView.postDelayed({
            addTypingIndicator()
            scrollToBottom()
            // Simulate AI response after 1.5s
            recyclerView.postDelayed({
                messageAdapter.removeTypingIndicator()
                addAiMessage(getAiResponse(text), currentTime())
                scrollToBottom()
            }, 1500)
        }, 300)
    }

    private fun getAiResponse(input: String): String {
        return when {
            input.lowercase().contains("ios") || input.lowercase().contains("design") ->
                "Great choice! iOS design emphasizes clarity, depth, and deference. Use SF Pro fonts, subtle blurs, and frosted glass effects."
            input.lowercase().contains("quantum") ->
                "Quantum computing uses quantum bits (qubits) that can exist in superposition, enabling parallel computations impossible for classical computers."
            input.lowercase().contains("poem") ->
                "Beneath the stars so vast and bright,\nThe world hums softly through the night."
            input.lowercase().contains("trip") || input.lowercase().contains("travel") ->
                "I'd recommend starting with the highlights: local culture, landmarks, and cuisine. Want me to create a detailed itinerary?"
            input.lowercase().contains("code") || input.lowercase().contains("website") ->
                "I can help you build a website! What tech stack are you thinking — React, Vue, or plain HTML/CSS?"
            else ->
                "That's an interesting topic! I'm here to help you explore ideas, solve problems, and create amazing things. What would you like to dive into?"
        }
    }

    private fun addWelcome() {
        messages.add(Message(messageIdCounter++, MessageType.WELCOME))
        messageAdapter.notifyItemInserted(messages.size - 1)
    }

    private fun addAiMessage(text: String, time: String) {
        messageAdapter.addMessage(Message(messageIdCounter++, MessageType.AI, text, time))
    }

    private fun addUserMessage(text: String, time: String) {
        messageAdapter.addMessage(Message(messageIdCounter++, MessageType.USER, text, time))
    }

    private fun addTypingIndicator() {
        if (!messageAdapter.hasTypingIndicator()) {
            messageAdapter.addMessage(Message(messageIdCounter++, MessageType.TYPING))
        }
    }

    private fun scrollToBottom() {
        recyclerView.post {
            recyclerView.scrollToPosition(messageAdapter.itemCount - 1)
        }
    }

    private fun currentTime(): String {
        return SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
    }

    private fun handleWideLayout() {
        val isWide = resources.getBoolean(R.bool.is_wide_layout)
        if (isWide) {
            // Persistent sidebar - open by default, lock it
            drawerLayout.openDrawer(GravityCompat.START)
            drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_OPEN)
            btnMenu.visibility = View.GONE
            btnCloseSidebar.visibility = View.GONE
        } else {
            drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED)
            btnMenu.visibility = View.VISIBLE
            btnCloseSidebar.visibility = View.VISIBLE
        }
    }

    override fun onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            val isWide = resources.getBoolean(R.bool.is_wide_layout)
            if (!isWide) {
                drawerLayout.closeDrawer(GravityCompat.START)
                return
            }
        }
        super.onBackPressed()
    }
}
