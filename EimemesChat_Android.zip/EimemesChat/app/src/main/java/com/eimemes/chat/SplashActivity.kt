package com.eimemes.chat

import android.content.Intent
import android.graphics.LinearGradient
import android.graphics.Shader
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.WindowManager
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Edge-to-edge
        window.setFlags(
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        )

        setContentView(R.layout.activity_splash)

        val tvTitle = findViewById<TextView>(R.id.splashTitle)

        // Apply gradient to title after layout
        tvTitle.post {
            val paint = tvTitle.paint
            val width = paint.measureText(tvTitle.text.toString())
            val shader = LinearGradient(
                0f, 0f, width, tvTitle.textSize,
                intArrayOf(0xFF5e9cff.toInt(), 0xFFc96eff.toInt()),
                null,
                Shader.TileMode.CLAMP
            )
            tvTitle.paint.shader = shader
            tvTitle.invalidate()
        }

        // Navigate to MainActivity after 2 seconds
        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(Intent(this, MainActivity::class.java))
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
            finish()
        }, 2000)
    }
}
