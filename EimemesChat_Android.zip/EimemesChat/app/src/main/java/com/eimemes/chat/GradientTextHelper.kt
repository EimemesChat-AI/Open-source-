package com.eimemes.chat

import android.graphics.LinearGradient
import android.graphics.Shader
import android.widget.TextView
import androidx.core.content.ContextCompat

object GradientTextHelper {

    /**
     * Applies a blue-to-purple gradient shader to a TextView.
     * Must be called after the view has been laid out (or inside doOnLayout).
     */
    fun applyGradient(textView: TextView) {
        val paint = textView.paint
        val width = paint.measureText(textView.text.toString())
        if (width <= 0f) return
        val shader = LinearGradient(
            0f, 0f, width, textView.textSize,
            intArrayOf(
                0xFF5e9cff.toInt(),
                0xFFc96eff.toInt()
            ),
            null,
            Shader.TileMode.CLAMP
        )
        textView.paint.shader = shader
        textView.invalidate()
    }
}
