package com.eimemes.chat

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.view.doOnLayout
import androidx.recyclerview.widget.RecyclerView

class MessageAdapter(private val messages: MutableList<Message>) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        const val VIEW_TYPE_WELCOME = 0
        const val VIEW_TYPE_AI = 1
        const val VIEW_TYPE_USER = 2
        const val VIEW_TYPE_TYPING = 3
    }

    override fun getItemViewType(position: Int): Int {
        return when (messages[position].type) {
            MessageType.WELCOME -> VIEW_TYPE_WELCOME
            MessageType.AI -> VIEW_TYPE_AI
            MessageType.USER -> VIEW_TYPE_USER
            MessageType.TYPING -> VIEW_TYPE_TYPING
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return when (viewType) {
            VIEW_TYPE_WELCOME -> {
                val view = inflater.inflate(R.layout.item_welcome, parent, false)
                WelcomeViewHolder(view)
            }
            VIEW_TYPE_AI -> {
                val view = inflater.inflate(R.layout.item_message_ai, parent, false)
                AiViewHolder(view)
            }
            VIEW_TYPE_USER -> {
                val view = inflater.inflate(R.layout.item_message_user, parent, false)
                UserViewHolder(view)
            }
            VIEW_TYPE_TYPING -> {
                val view = inflater.inflate(R.layout.item_message_typing, parent, false)
                TypingViewHolder(view)
            }
            else -> throw IllegalArgumentException("Unknown view type: $viewType")
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val message = messages[position]
        when (holder) {
            is WelcomeViewHolder -> holder.bind()
            is AiViewHolder -> holder.bind(message)
            is UserViewHolder -> holder.bind(message)
            is TypingViewHolder -> holder.bind()
        }
    }

    override fun getItemCount(): Int = messages.size

    fun addMessage(message: Message) {
        messages.add(message)
        notifyItemInserted(messages.size - 1)
    }

    fun removeTypingIndicator() {
        val idx = messages.indexOfFirst { it.type == MessageType.TYPING }
        if (idx != -1) {
            messages.removeAt(idx)
            notifyItemRemoved(idx)
        }
    }

    fun hasTypingIndicator(): Boolean = messages.any { it.type == MessageType.TYPING }

    // ---- ViewHolders ----

    inner class WelcomeViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val tvTitle: TextView = view.findViewById(R.id.tvGradientTitle)

        fun bind() {
            tvTitle.doOnLayout {
                GradientTextHelper.applyGradient(tvTitle)
            }
        }
    }

    inner class AiViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val tvMessage: TextView = view.findViewById(R.id.tvAIMessage)
        private val tvTime: TextView = view.findViewById(R.id.tvAITime)

        fun bind(message: Message) {
            tvMessage.text = message.text
            tvTime.text = message.time
        }
    }

    inner class UserViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val tvMessage: TextView = view.findViewById(R.id.tvUserMessage)
        private val tvTime: TextView = view.findViewById(R.id.tvUserTime)

        fun bind(message: Message) {
            tvMessage.text = message.text
            tvTime.text = message.time
        }
    }

    inner class TypingViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val dot1: View = view.findViewById(R.id.dot1)
        private val dot2: View = view.findViewById(R.id.dot2)
        private val dot3: View = view.findViewById(R.id.dot3)

        fun bind() {
            TypingAnimationHelper.startTypingAnimation(dot1, dot2, dot3)
        }
    }
}
