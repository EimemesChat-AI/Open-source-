package com.eimemes.chat

import android.animation.ObjectAnimator
import android.animation.AnimatorSet
import android.view.View
import android.animation.ValueAnimator

object TypingAnimationHelper {

    fun startTypingAnimation(dot1: View, dot2: View, dot3: View) {
        val dots = listOf(dot1, dot2, dot3)
        dots.forEachIndexed { index, dot ->
            val animator = ObjectAnimator.ofFloat(dot, View.TRANSLATION_Y, 0f, -18f).apply {
                duration = 300
                startDelay = (index * 150).toLong()
                repeatMode = ObjectAnimator.REVERSE
                repeatCount = ObjectAnimator.INFINITE
                interpolator = android.view.animation.DecelerateInterpolator()
            }
            dot.tag = animator
            animator.start()
        }
    }

    fun stopTypingAnimation(dot1: View, dot2: View, dot3: View) {
        listOf(dot1, dot2, dot3).forEach { dot ->
            (dot.tag as? ObjectAnimator)?.cancel()
            dot.translationY = 0f
        }
    }
}
